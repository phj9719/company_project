(function()
{
	return function()
	{
		nexacro._setCSSMaps(
		{

		},
		{
            "includeStatusMap" : true
		}
		);
		var imgcache = nexacro._getImageCacheMaps();

	};
}
)();
