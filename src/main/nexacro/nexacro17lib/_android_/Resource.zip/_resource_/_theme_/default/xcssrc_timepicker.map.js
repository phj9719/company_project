(function()
{
	return function()
	{
		nexacro._setCSSMaps(
		{
            "timepicker" :
            			{
            				"self" :
            				{
            					"enabled" :
            					{
            						"border" : nexacro.BorderObject("1px solid #dbdbdb")
            					}
            				}
            			},
            			"Button" :
            			{
            				"class" :
            				[
            					{
            						"dropbutton" :
            						{
            							"self" :
            							{
            								"enabled" :
            								{
            									"icon" : nexacro.UrlObject("URL('imagerc::ico_clock.png')")
            								},
            								"disabled" :
            								{
            								},
            								"focused" :
            								{
            									"icon" : nexacro.UrlObject("URL('imagerc::ico_clock.png')")
            								},
            								"mouseover" :
            								{
            									"icon" : nexacro.UrlObject("URL('imagerc::ico_clock.png')")
            								},
            								"pushed" :
            								{
            									"icon" : nexacro.UrlObject("URL('imagerc::ico_clock.png')")
            								},
            								"selected" :
            								{
            									"icon" : nexacro.UrlObject("URL('imagerc::ico_clock.png')")
            								}
            							}
            						}
            					},
            					{
            						"upButton" :
            						{
            							"self" :
            							{
            								"enabled" :
            								{
            									"icon" : nexacro.UrlObject("URL('imagerc::btn_tUp.png')")
            								}
            							}
            						}
            					},
            					{
            						"downButton" :
            						{
            							"self" :
            							{
            								"enabled" :
            								{
            									"icon" : nexacro.UrlObject("URL('imagerc::btn_tDown.png')")
            								}
            							}
            						}
            					},
            					{
            						"okButton" :
            						{
            							"self" :
            							{
            								"enabled" :
            								{
            									"color" : nexacro.ColorObject("#ffffff"),
            									"font" : nexacro.FontObject("normal bold  12pt/normal \"Noto Sans CJK KR Bold\"")
            								}
            							}
            						}
            					}
            				]
            			},
            			"MaskEdit" :
            			{
            				"class" :
            				[
            					{
            						"timeMedt" :
            						{
            							"self" :
            							{
            								"enabled" :
            								{
            									"border" : nexacro.BorderObject("0px none, 0px none, 0px none, 0px none")
            								}
            							}
            						}
            					}
            				]
            			},
            			"PopupDiv" :
            			{
            				"class" :
            				[
            					{
            						"div_timepicker" :
            						{
            							"self" :
            							{
            								"enabled" :
            								{
            									"border" : nexacro.BorderObject("1px solid #dbdbdb")
            								}
            							}
            						}
            					}
            				]
            			},
            			"Edit" :
            			{
            				"class" :
            				[
            					{
            						"edt_tTimeEdit" :
            						{
            							"self" :
            							{
            								"enabled" :
            								{
            									"border" : nexacro.BorderObject("1px solid transparent"),
            									"font" : nexacro.FontObject("normal bold  15pt/normal \"Noto Sans CJK KR Bold\""),
            									"color" : nexacro.ColorObject("#555555")
            								}
            							}
            						}
            					}
            				]
            			}
		},
		{
            "includeStatusMap" : true
		}
		);
		var imgcache = nexacro._getImageCacheMaps();

	};
}
)();
